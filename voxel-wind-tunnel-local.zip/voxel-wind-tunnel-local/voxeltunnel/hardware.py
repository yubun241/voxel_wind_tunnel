"""計算バックエンドとメモリの自動判定。

優先順位: CUDA (NVIDIA) → Vulkan (AMD / Intel / NVIDIA) → Metal (macOS) → CPU。
Taichi が import できない環境では NumPy 実装にフォールバックする。
"""
from __future__ import annotations

import ctypes
import os
import platform
import subprocess
import sys
from dataclasses import dataclass, field

BYTES_PER_CELL = 19 * 4 * 2 + 4 * 4 + 1 + 4   # f0,f1 + ux,uy,uz,rho + flags + cross(一時)
SAFETY = 0.70                                   # 使う上限 = 使えるメモリ × SAFETY


@dataclass
class Hardware:
    backend: str                # "cuda" | "vulkan" | "metal" | "cpu" | "numpy"
    device: str
    mem_bytes: int              # 計算に使えるメモリ (VRAM または RAM)
    mem_kind: str               # "vram" | "ram"
    cpu_threads: int
    max_cells: int
    presets: list = field(default_factory=list)
    notes: list = field(default_factory=list)

    def to_dict(self):
        return {
            "backend": self.backend, "device": self.device, "mem_bytes": self.mem_bytes, "mem_kind": self.mem_kind,
            "cpu_threads": self.cpu_threads, "max_cells": self.max_cells, "presets": self.presets, "notes": self.notes,
        }


def system_ram_bytes() -> int:
    try:
        if sys.platform == "win32":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            st = MEMORYSTATUSEX(); st.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st))
            return int(st.ullAvailPhys)
        if sys.platform == "darwin":
            out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True)
            return int(out.strip()) * 3 // 4   # 空き容量を直接取れないので総量の 3/4 を使う
        # Linux
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return 8 * 1024 ** 3


def nvidia_vram_bytes() -> tuple[int, str] | None:
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.free,name", "--format=csv,noheader,nounits"],
            text=True, timeout=5, stderr=subprocess.DEVNULL)
        best = None
        for line in out.strip().splitlines():
            mb, name = line.split(",", 1)
            v = int(float(mb)) * 1024 ** 2
            if best is None or v > best[0]:
                best = (v, name.strip())
        return best
    except Exception:
        return None


def _presets_for(max_cells: int, backend: str) -> list:
    """2:1:1 の格子を 128 から上限まで。CPU 系は速度の観点で上限を抑える。"""
    out = []
    cap = max_cells
    if backend in ("cpu", "numpy"):
        # CPU は 20〜80 MLUPS 程度。1 流過に数分で収まる範囲を上限にする
        cap = min(cap, 24_000_000 if backend == "cpu" else 2_000_000)
    for nx in (128, 160, 192, 256, 320, 384, 448, 512, 640, 768, 1024):
        ny = nz = nx // 2
        n = nx * ny * nz
        if n > cap:
            break
        out.append({"nx": nx, "ny": ny, "nz": nz, "cells": n, "mem_mb": n * BYTES_PER_CELL // 1024 ** 2})
    if not out:
        out.append({"nx": 96, "ny": 48, "nz": 48, "cells": 96 * 48 * 48, "mem_mb": 96 * 48 * 48 * BYTES_PER_CELL // 1024 ** 2})
    return out


def detect(prefer: str | None = None, mem_gb: float | None = None) -> Hardware:
    notes = []
    threads = os.cpu_count() or 4
    ram = system_ram_bytes()
    try:
        import taichi as ti  # noqa: F401
        have_ti = True
    except Exception as e:  # pragma: no cover
        have_ti = False
        notes.append(f"Taichi を import できません ({type(e).__name__}: {e}). NumPy 実装 (低速) で動かします。")

    if not have_ti:
        mem = int(mem_gb * 1024 ** 3) if mem_gb else ram
        hw = Hardware("numpy", f"{platform.processor() or platform.machine()} ({threads} threads)", mem, "ram", threads, int(mem * SAFETY / BYTES_PER_CELL), notes=notes)
        hw.presets = _presets_for(hw.max_cells, "numpy")
        return hw

    import taichi as ti
    order = [prefer] if prefer else (["metal", "vulkan", "cpu"] if sys.platform == "darwin" else ["cuda", "vulkan", "cpu"])
    chosen = None
    for name in order:
        arch = {"cuda": ti.cuda, "vulkan": ti.vulkan, "metal": ti.metal, "cpu": ti.cpu}.get(name)
        if arch is None:
            continue
        try:
            kw = {"arch": arch, "log_level": "error", "offline_cache": True}
            if name == "cuda":
                kw["device_memory_fraction"] = 0.85
            ti.init(**kw)
            # 実際にカーネルが動くか確認
            @ti.kernel
            def _probe() -> ti.i32:
                s = 0
                for i in range(64):
                    s += i
                return s
            if _probe() != 2016:
                raise RuntimeError("probe failed")
            chosen = name
            break
        except Exception as e:
            notes.append(f"{name}: 利用不可 ({type(e).__name__})")
            try:
                ti.reset()
            except Exception:
                pass
    if chosen is None:
        chosen = "cpu"
        ti.init(arch=ti.cpu, log_level="error")

    device = ""
    if chosen == "cuda":
        v = nvidia_vram_bytes()
        if v:
            mem, device, kind = int(v[0] * 0.85), v[1], "vram"
        else:
            mem, device, kind = 4 * 1024 ** 3, "NVIDIA GPU", "vram"
            notes.append("nvidia-smi が無いため VRAM を 4 GB と仮定しました。--mem-gb で上書きできます。")
    elif chosen in ("vulkan", "metal"):
        if sys.platform == "darwin":
            mem, device, kind = ram, "Apple GPU (unified memory)", "ram"
        else:
            v = nvidia_vram_bytes()
            if v:
                mem, device, kind = int(v[0] * 0.85), v[1] + " (Vulkan)", "vram"
            else:
                mem, device, kind = 4 * 1024 ** 3, f"{chosen} GPU", "vram"
                notes.append("GPU メモリ量を取得できないため 4 GB と仮定しました。--mem-gb で上書きできます。")
    else:
        mem, device, kind = ram, f"{platform.processor() or platform.machine()} ({threads} threads)", "ram"

    if mem_gb:
        mem = int(mem_gb * 1024 ** 3)
    hw = Hardware(chosen, device, mem, kind, threads, int(mem * SAFETY / BYTES_PER_CELL), notes=notes)
    hw.presets = _presets_for(hw.max_cells, chosen)
    return hw
