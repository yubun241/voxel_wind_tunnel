"""python -m voxeltunnel  — ハードウェアを判定してサーバを起動し、ブラウザを開く。"""
from __future__ import annotations

import argparse
import socket
import sys
import threading
import webbrowser

from . import hardware


def _free_port(start: int) -> int:
    for p in range(start, start + 50):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


THREE_URL = "https://cdn.jsdelivr.net/npm/three@0.165.0/build/three.module.js"


def ensure_three():
    """描画ライブラリ (Three.js) を初回だけ static/vendor に保存する。失敗してもブラウザが CDN から読む。"""
    from pathlib import Path
    dst = Path(__file__).parent / "static" / "vendor" / "three.module.js"
    if dst.exists():
        return
    try:
        import urllib.request
        dst.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(THREE_URL, timeout=20) as r:
            data = r.read()
        if b"export" in data[-2000:] or b"export" in data[:2000]:
            dst.write_bytes(data)
            print(f"Three.js を同梱しました ({len(data) // 1024} KB)。以後はオフラインでも描画できます。")
    except Exception as e:
        print(f"Three.js のダウンロードに失敗 ({type(e).__name__})。ブラウザが CDN から読み込みます。")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="voxeltunnel", description="ボクセル風洞 ローカル版")
    ap.add_argument("--arch", choices=["cuda", "vulkan", "metal", "cpu", "numpy"], help="計算バックエンドを固定する (既定: 自動)")
    ap.add_argument("--mem-gb", type=float, help="計算に使うメモリ量 [GB] を上書きする")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args(argv)

    ensure_three()
    print("ボクセル風洞 ローカル版 — ハードウェアを判定中…")
    if a.arch == "numpy":
        hw = hardware.Hardware("numpy", "NumPy (強制)", int((a.mem_gb or 4) * 1024 ** 3), "ram", 1, 2_000_000)
        hw.presets = hardware._presets_for(hw.max_cells, "numpy")
    else:
        hw = hardware.detect(prefer=a.arch, mem_gb=a.mem_gb)

    if hw.backend == "numpy":
        from .solver_numpy import NumpySolver as Solver
    else:
        from .solver_taichi import TaichiSolver as Solver
    solver = Solver()

    from .server import serve
    port = _free_port(a.port)
    srv, worker = serve(solver, hw, port=port)
    url = f"http://127.0.0.1:{port}/"
    print(f"  backend : {hw.backend}  ({hw.device})")
    print(f"  memory  : {hw.mem_bytes / 1024**3:.1f} GB {hw.mem_kind}  → 最大 {hw.max_cells:,} cells")
    for n in hw.notes:
        print(f"  note    : {n}")
    print(f"  URL     : {url}")
    print("終了するにはこのウィンドウで Ctrl+C を押してください。")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
