"""NumPy 実装の D3Q19 LBM (フォールバック / 参照実装)。

Taichi 実装と同じ境界条件・同じ力の評価 (運動量交換法)。
速度は 1〜5 MLUPS 程度なので、小さい格子でしか実用にならない。
"""
from __future__ import annotations

import numpy as np

from .lattice import BELT, BODY, C, CX, CY, CZ, FLUID, OPP, REFL_Y, REFL_Z, SLIP, W_NP, WALL
from .voxel_np import voxelize


def _feq(rho, u):
    # rho: (...), u: (3, ...)
    cu = np.tensordot(C, u, axes=(1, 0))                      # (19, ...)
    usq = (u * u).sum(axis=0)
    return W_NP.reshape((19,) + (1,) * (u.ndim - 1)) * rho * (1 + 3 * cu + 4.5 * cu * cu - 1.5 * usq)


class NumpySolver:
    name = "numpy"

    def __init__(self):
        self.f = None

    # ------------------------------------------------------------ setup
    def prepare(self, nx, ny, nz, tris, walls):
        self.nx, self.ny, self.nz = nx, ny, nz
        self.flags, solid, area = voxelize(tris, nx, ny, nz, walls)
        self.fluid = self.flags == FLUID
        self.f = np.tile(W_NP.reshape(19, 1, 1, 1), (1, nx, ny, nz)).astype(np.float32)
        self.ux = np.zeros((nx, ny, nz), np.float32); self.uy = self.ux.copy(); self.uz = self.ux.copy()
        self.rho = np.ones((nx, ny, nz), np.float32)
        self.force = np.zeros(3)
        # 境界近傍セルのマスクを事前計算
        self.src_flag = []
        for i in range(19):
            sf = np.roll(self.flags, shift=(CX[i], CY[i], CZ[i]), axis=(0, 1, 2))
            self.src_flag.append(sf)
        self.set_params(0.5, 0.0, 0.1, 0)
        # 静止流体での運動量交換力 (基準圧 rho0/3 の寄与)。閉じた物体では 0、壁に取り付けた物体では非 0。
        self.F0 = np.zeros(3)
        for i in range(19):
            m = (self.src_flag[i] == BODY) & self.fluid
            self.F0 += 2 * W_NP[OPP[i]] * m.sum() * C[OPP[i]]
        return {"solid": solid, "area": area}

    def set_params(self, tau0, uin, cs, ground):
        self.tau0, self.uin, self.cs, self.ground = float(tau0), float(uin), float(cs), int(ground)

    # ------------------------------------------------------------ step
    def step(self, k=1):
        for _ in range(k):
            self._step()

    def _step(self):
        nx, ny, nz = self.nx, self.ny, self.nz
        f = self.f
        uinv = np.array([self.uin, 0, 0], np.float32)
        fs = np.empty_like(f)
        force = np.zeros(3)
        for i in range(19):
            fs[i] = np.roll(f[i], shift=(CX[i], CY[i], CZ[i]), axis=(0, 1, 2))
            sf = self.src_flag[i]
            o = OPP[i]
            fl = self.fluid
            m = (sf == BODY) & fl
            if m.any():
                fo = f[o][m]; fs[i][m] = fo
                force += 2 * fo.sum() * C[o]
            m = (sf == BELT) & fl
            if m.any():
                fs[i][m] = f[o][m] - 6 * W_NP[o] * (C[o] @ uinv)
            m = (sf == WALL) & fl
            if m.any():
                fs[i][m] = f[o][m]
            m = (sf == SLIP) & fl
            if m.any():
                # 鏡面反射: 法線は壁の位置で決める (z 壁優先)
                zz = np.zeros((nx, ny, nz), bool); zz[:, :, 0] = True; zz[:, :, nz - 1] = True
                sz = np.roll(zz, shift=CZ[i], axis=2)
                mz = m & sz; my = m & ~sz
                if mz.any(): fs[i][mz] = f[REFL_Z[i]][mz]
                if my.any(): fs[i][my] = f[REFL_Y[i]][my]
        # 流入 / 流出 / 上下の自由流
        eq_in = _feq(np.float32(1.0), uinv.reshape(3, 1, 1))
        fs[:, 0, :, :] = eq_in
        fs[:, :, :, nz - 1] = eq_in
        if not self.ground:
            fs[:, :, :, 0] = eq_in
        fs[:, nx - 1, :, :] = f[:, nx - 2, :, :]
        # マクロ量
        rho = fs.sum(axis=0)
        u = np.tensordot(C.T, fs, axes=(1, 0)) / rho       # (3, ...)
        usq = (u * u).sum(axis=0)
        over = usq > 0.09
        if over.any():
            u[:, over] *= (0.3 / np.sqrt(usq[over]))
        feq = _feq(rho, u)
        d = fs - feq
        # Smagorinsky
        cxx = (C[:, 0] ** 2).reshape(19, 1, 1, 1); cyy = (C[:, 1] ** 2).reshape(19, 1, 1, 1); czz = (C[:, 2] ** 2).reshape(19, 1, 1, 1)
        cxy = (C[:, 0] * C[:, 1]).reshape(19, 1, 1, 1); cxz = (C[:, 0] * C[:, 2]).reshape(19, 1, 1, 1); cyz = (C[:, 1] * C[:, 2]).reshape(19, 1, 1, 1)
        pxx = (cxx * d).sum(0); pyy = (cyy * d).sum(0); pzz = (czz * d).sum(0)
        pxy = (cxy * d).sum(0); pxz = (cxz * d).sum(0); pyz = (cyz * d).sum(0)
        Q = np.sqrt(2 * (pxx ** 2 + pyy ** 2 + pzz ** 2 + 2 * (pxy ** 2 + pxz ** 2 + pyz ** 2)))
        tau = 0.5 * (self.tau0 + np.sqrt(self.tau0 ** 2 + 18 * self.cs ** 2 * Q / rho))
        om = 1.0 / tau
        out = fs - om * d
        # 境界セル (流入/流出/自由流) は衝突させない
        out[:, 0] = fs[:, 0]; out[:, nx - 1] = fs[:, nx - 1]; out[:, :, :, nz - 1] = fs[:, :, :, nz - 1]
        if not self.ground:
            out[:, :, :, 0] = fs[:, :, :, 0]
        # 固体セルは触らない
        fl = self.fluid
        self.f[:, fl] = out[:, fl].astype(np.float32)
        self.ux[fl] = u[0][fl]; self.uy[fl] = u[1][fl]; self.uz[fl] = u[2][fl]; self.rho[fl] = rho[fl]
        self.force = force

    # ------------------------------------------------------------ sampling
    def get_force(self):
        return [float(v) for v in (self.force - self.F0)]

    def slice(self, axis, pos, field, uin):
        nx, ny, nz = self.nx, self.ny, self.nz
        if axis == "z":
            k = min(nz - 1, int(pos * nz)); ux, uy, uz, rho, fl = self.ux[:, :, k], self.uy[:, :, k], self.uz[:, :, k], self.rho[:, :, k], self.flags[:, :, k]
        elif axis == "y":
            k = min(ny - 1, int(pos * ny)); ux, uy, uz, rho, fl = self.ux[:, k, :], self.uy[:, k, :], self.uz[:, k, :], self.rho[:, k, :], self.flags[:, k, :]
        else:
            k = min(nx - 1, int(pos * nx)); ux, uy, uz, rho, fl = self.ux[k], self.uy[k], self.uz[k], self.rho[k], self.flags[k]
        if field == "u":
            v = np.sqrt(ux ** 2 + uy ** 2 + uz ** 2) / uin
        elif field == "ux":
            v = ux / uin
        else:
            v = ((rho - 1) / 3) / (0.5 * uin * uin)
        v = v.astype(np.float32).copy()
        v[fl == BODY] = np.nan
        return v

    def coarse(self, maxdim):
        s = max(1, int(np.ceil(max(self.nx, self.ny, self.nz) / maxdim)))
        ux, uy, uz = self.ux[::s, ::s, ::s], self.uy[::s, ::s, ::s], self.uz[::s, ::s, ::s]
        out = np.stack([ux, uy, uz], axis=-1).astype(np.float32)
        out[self.flags[::s, ::s, ::s] == BODY] = 0
        return out, s

    def cp(self, verts, normals, uin):
        nx, ny, nz = self.nx, self.ny, self.nz
        out = np.full(len(verts), np.nan, np.float32)
        found = np.zeros(len(verts), bool)
        for d in (1.5, 2.5, 3.5):
            for sg in (1, -1):
                p = np.floor(verts + sg * d * normals).astype(np.int64)
                ok = (~found) & (p[:, 0] >= 1) & (p[:, 0] < nx - 1) & (p[:, 1] >= 0) & (p[:, 1] < ny) & (p[:, 2] >= 1) & (p[:, 2] < nz - 1)
                idx = np.nonzero(ok)[0]
                if len(idx) == 0:
                    continue
                q = p[idx]
                fluid = self.flags[q[:, 0], q[:, 1], q[:, 2]] == FLUID
                sel = idx[fluid]; qq = q[fluid]
                out[sel] = ((self.rho[qq[:, 0], qq[:, 1], qq[:, 2]] - 1) / 3) / (0.5 * uin * uin)
                found[sel] = True
        return out

    def release(self):
        self.f = None
