"""NumPy ボクセライザ (フォールバック用)。

格子座標に置かれた三角形 (nt,3,3) → flags (nx,ny,nz) uint8。
表面サンプリング + x 方向レイのパリティで内部充填。壁層を上書きして返す。
"""
from __future__ import annotations

import numpy as np

from .lattice import BODY


def voxelize(tris: np.ndarray, nx: int, ny: int, nz: int, walls: dict) -> tuple[np.ndarray, int, int]:
    flags = np.zeros((nx, ny, nz), dtype=np.uint8)
    a, b, c = tris[:, 0], tris[:, 1], tris[:, 2]

    # ---- 表面サンプリング: 辺長に応じて三角形を細分し、点をセルに落とす
    e = np.maximum.reduce([np.linalg.norm(b - a, axis=1), np.linalg.norm(c - a, axis=1), np.linalg.norm(c - b, axis=1)])
    n = np.maximum(1, np.ceil(e / 0.5)).astype(np.int32)
    for nn in np.unique(n):
        sel = n == nn
        i, j = np.meshgrid(np.arange(nn + 1), np.arange(nn + 1), indexing="ij")
        m = (i + j) <= nn
        s = (i[m] / nn).astype(np.float32); u = (j[m] / nn).astype(np.float32)
        A, B, Cc = a[sel], b[sel], c[sel]
        P = A[:, None, :] + (B - A)[:, None, :] * s[None, :, None] + (Cc - A)[:, None, :] * u[None, :, None]
        P = np.floor(P.reshape(-1, 3)).astype(np.int64)
        ok = (P[:, 0] >= 1) & (P[:, 0] < nx - 1) & (P[:, 1] >= 0) & (P[:, 1] < ny) & (P[:, 2] >= 1) & (P[:, 2] < nz - 1)
        P = P[ok]
        flags[P[:, 0], P[:, 1], P[:, 2]] = BODY

    # ---- 内部充填: (y,z) 列ごとに x 方向の交差パリティ
    cross = np.zeros((nx + 1, ny, nz), dtype=np.int32)
    area = (b[:, 1] - a[:, 1]) * (c[:, 2] - a[:, 2]) - (b[:, 2] - a[:, 2]) * (c[:, 1] - a[:, 1])
    for t in np.nonzero(np.abs(area) > 1e-9)[0]:
        y0, z0 = a[t, 1], a[t, 2]; y1, z1 = b[t, 1], b[t, 2]; y2, z2 = c[t, 1], c[t, 2]
        ymin, ymax = max(0, int(np.floor(min(y0, y1, y2)))), min(ny - 1, int(np.ceil(max(y0, y1, y2))))
        zmin, zmax = max(0, int(np.floor(min(z0, z1, z2)))), min(nz - 1, int(np.ceil(max(z0, z1, z2))))
        if ymin > ymax or zmin > zmax:
            continue
        cy, cz = np.meshgrid(np.arange(ymin, ymax + 1), np.arange(zmin, zmax + 1), indexing="ij")
        py, pz = cy + 0.5137, cz + 0.5071
        w0 = ((y1 - py) * (z2 - pz) - (z1 - pz) * (y2 - py)) / area[t]
        w1 = ((y2 - py) * (z0 - pz) - (z2 - pz) * (y0 - py)) / area[t]
        w2 = 1 - w0 - w1
        inside = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if not inside.any():
            continue
        x = w0 * a[t, 0] + w1 * b[t, 0] + w2 * c[t, 0]
        k = np.ceil(x[inside] - 0.5).astype(np.int64)
        k = np.clip(k, 0, nx)
        np.add.at(cross, (k, cy[inside], cz[inside]), 1)
    par = (np.cumsum(cross[:nx], axis=0) % 2).astype(bool)
    par[0] = False; par[nx - 1] = False
    flags[par] = BODY

    interior = flags[1:nx - 1]
    area_cells = int((interior == BODY).any(axis=0).sum())
    solid = int((flags == BODY).sum())

    # ---- 壁層 (取付面の壁は物体も上書き)
    if walls.get("zlo"): flags[:, :, 0] = walls["zlo"]
    if walls.get("zhi"): flags[:, :, nz - 1] = walls["zhi"]
    if walls.get("ylo"): flags[:, 0, :] = walls["ylo"]
    if walls.get("yhi"): flags[:, ny - 1, :] = walls["yhi"]
    return flags, solid, area_cells
