"""ローカル HTTP サーバ。

- ソルバは 1 本のワーカースレッドが所有する (Taichi はスレッド安全でないため)。
  HTTP ハンドラはコマンドをキューに積み、結果を待つ。
- 計算ループはワーカー内で回り、合間にキューのコマンドを処理する。
- 標準ライブラリのみ (http.server + threading)。外部通信なし。
"""
from __future__ import annotations

import json
import queue
import threading
import time
import traceback
from concurrent.futures import Future
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import numpy as np

STATIC = Path(__file__).parent / "static"
FORCE_EVERY = 10


class Worker(threading.Thread):
    def __init__(self, solver, hw):
        super().__init__(daemon=True)
        self.solver, self.hw = solver, hw
        self.q: queue.Queue = queue.Queue()
        self.running = False
        self.prepared = False
        self.step = 0
        self.spf = 8
        self.hist: list = []
        self.rate = 0.0
        self._rate_t = time.perf_counter(); self._rate_n = 0
        self.error = ""
        self.tris = None  # 格子座標の三角形 (nt,3,3)
        self.normals = None

    def submit(self, fn, *a, **k):
        fut: Future = Future()
        self.q.put((fut, fn, a, k))
        return fut.result()

    def run(self):
        while True:
            try:
                fut, fn, a, k = self.q.get(timeout=0.0 if self.running else 0.2)
                try:
                    fut.set_result(fn(*a, **k))
                except Exception as e:
                    traceback.print_exc()
                    fut.set_exception(e)
                continue
            except queue.Empty:
                pass
            if self.running and self.prepared:
                try:
                    self._advance()
                except Exception as e:
                    traceback.print_exc()
                    self.running = False
                    self.error = f"{type(e).__name__}: {e}"

    def _advance(self):
        k = self.spf
        # 力を FORCE_EVERY ステップごとに記録できるよう k を切る
        nxt = (self.step // FORCE_EVERY + 1) * FORCE_EVERY
        k = min(k, nxt - self.step)
        self.solver.step(k)
        self.step += k
        self._rate_n += k
        if self.step % FORCE_EVERY == 0:
            F = self.solver.get_force()
            if not all(np.isfinite(F)):
                self.running = False
                self.error = "発散しました。τ 下限を上げる、u_lb を下げる、解像度を上げる、のいずれかを試してください。"
            self.hist.append({"step": self.step, "F": F})
        now = time.perf_counter()
        if now - self._rate_t > 1.0:
            self.rate = self._rate_n / (now - self._rate_t)
            self._rate_t = now; self._rate_n = 0

    # ---- commands (ワーカースレッドで実行される)
    def cmd_prepare(self, nx, ny, nz, tris, walls):
        self.running = False
        self.prepared = False
        self.error = ""
        t0 = time.perf_counter()
        r = self.solver.prepare(nx, ny, nz, tris, walls)
        self.tris = tris
        a, b, c = tris[:, 0], tris[:, 1], tris[:, 2]
        n = np.cross(b - a, c - a)
        n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
        self.normals = np.repeat(n, 3, axis=0).astype(np.float32)
        self.step = 0; self.hist = []; self.rate = 0.0
        self.prepared = True
        r["ms"] = (time.perf_counter() - t0) * 1000
        r["nx"], r["ny"], r["nz"] = nx, ny, nz
        return r

    def cmd_params(self, tau0, uin, cs, ground, spf):
        self.solver.set_params(tau0, uin, cs, ground)
        self.spf = max(1, min(64, int(spf)))
        return {"ok": True}

    def cmd_run(self, on):
        if not self.prepared:
            return {"ok": False, "error": "not prepared"}
        self.running = bool(on)
        self._rate_t = time.perf_counter(); self._rate_n = 0
        return {"ok": True}

    def cmd_slice(self, axis, pos, field, uin):
        return self.solver.slice(axis, pos, field, uin)

    def cmd_coarse(self, maxdim):
        return self.solver.coarse(maxdim)

    def cmd_cp(self, uin):
        verts = self.tris.reshape(-1, 3)
        return self.solver.cp(verts, self.normals, uin)

    def cmd_release(self):
        self.running = False; self.prepared = False
        self.solver.release()
        return {"ok": True}


def make_handler(worker: Worker):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # 静かに
            pass

        def _send(self, code, body, ctype="application/json", headers=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, code=200):
            self._send(code, json.dumps(obj).encode())

        def _bin(self, arr: np.ndarray, headers):
            self._send(200, np.ascontiguousarray(arr, np.float32).tobytes(), "application/octet-stream", headers)

        def do_GET(self):
            u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
            p = u.path
            try:
                if p == "/" or p == "/index.html":
                    self._send(200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
                elif p.startswith("/vendor/") and ".." not in p:
                    fp = STATIC / p.lstrip("/")
                    if fp.is_file():
                        self._send(200, fp.read_bytes(), "text/javascript; charset=utf-8")
                    else:
                        self._json({"error": "not found"}, 404)
                elif p == "/api/hardware":
                    self._json(worker.hw.to_dict())
                elif p == "/api/status":
                    since = int(q.get("since", 0))
                    self._json({"step": worker.step, "running": worker.running, "prepared": worker.prepared, "rate": worker.rate,
                                "hist": worker.hist[since:], "nhist": len(worker.hist), "error": worker.error})
                elif p == "/api/slice":
                    if not worker.prepared:
                        self._json({"error": "not prepared"}, 409); return
                    arr = worker.submit(worker.cmd_slice, q.get("axis", "y"), float(q.get("pos", 0.5)), q.get("field", "u"), float(q.get("uin", 0.05)))
                    self._bin(arr, {"X-Dims": f"{arr.shape[0]},{arr.shape[1]}"})
                elif p == "/api/coarse":
                    if not worker.prepared:
                        self._json({"error": "not prepared"}, 409); return
                    arr, s = worker.submit(worker.cmd_coarse, int(q.get("maxdim", 96)))
                    self._bin(arr, {"X-Dims": f"{arr.shape[0]},{arr.shape[1]},{arr.shape[2]}", "X-Stride": str(s)})
                elif p == "/api/cp":
                    if not worker.prepared:
                        self._json({"error": "not prepared"}, 409); return
                    arr = worker.submit(worker.cmd_cp, float(q.get("uin", 0.05)))
                    self._bin(arr, {})
                else:
                    self._json({"error": "not found"}, 404)
            except Exception as e:
                traceback.print_exc()
                self._json({"error": f"{type(e).__name__}: {e}"}, 500)

        def do_POST(self):
            u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
            n = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(n) if n else b""
            try:
                if u.path == "/api/prepare":
                    nx, ny, nz = int(q["nx"]), int(q["ny"]), int(q["nz"])
                    if nx * ny * nz > worker.hw.max_cells * 1.05:
                        self._json({"error": f"格子 {nx}×{ny}×{nz} はこの PC のメモリ上限 ({worker.hw.max_cells:,} cells) を超えます。"}, 400); return
                    tris = np.frombuffer(body, dtype=np.float32).reshape(-1, 3, 3).copy()
                    walls = {k: int(q.get(k, 0)) for k in ("zlo", "zhi", "ylo", "yhi")}
                    self._json(worker.submit(worker.cmd_prepare, nx, ny, nz, tris, walls))
                elif u.path == "/api/params":
                    j = json.loads(body or b"{}")
                    self._json(worker.submit(worker.cmd_params, j["tau0"], j["uin"], j["cs"], j["ground"], j.get("spf", 8)))
                elif u.path == "/api/run":
                    self._json(worker.submit(worker.cmd_run, q.get("on", "1") == "1"))
                elif u.path == "/api/release":
                    self._json(worker.submit(worker.cmd_release))
                else:
                    self._json({"error": "not found"}, 404)
            except Exception as e:
                traceback.print_exc()
                self._json({"error": f"{type(e).__name__}: {e}"}, 500)

    return H


def serve(solver, hw, host="127.0.0.1", port=8765):
    worker = Worker(solver, hw)
    worker.start()
    srv = ThreadingHTTPServer((host, port), make_handler(worker))
    srv.daemon_threads = True
    return srv, worker
