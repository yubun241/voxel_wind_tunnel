"""Taichi 実装の D3Q19 LBM + Smagorinsky LES。

ブラウザ版 (WGSL) と同じアルゴリズム。CUDA / Vulkan / Metal / CPU で同じコードが動く。
フィールドは FieldsBuilder で確保し、格子を変えるときは destroy して作り直す。
"""
from __future__ import annotations

import math

import numpy as np
import taichi as ti

from .lattice import BELT, BODY, CX, CY, CZ, FLUID, OPP, REFL_Y, REFL_Z, SLIP, W, WALL

f32, i32, u8 = ti.f32, ti.i32, ti.u8


@ti.data_oriented
class TaichiSolver:
    name = "taichi"

    def __init__(self):
        self.tree = None
        self.nx = self.ny = self.nz = 0

    # ------------------------------------------------------------ alloc
    def _alloc(self, nx, ny, nz):
        self.release()
        self.nx, self.ny, self.nz = nx, ny, nz
        fb = ti.FieldsBuilder()
        self.f0 = ti.field(f32); self.f1 = ti.field(f32)
        self.flags = ti.field(u8)
        self.ux = ti.field(f32); self.uy = ti.field(f32); self.uz = ti.field(f32); self.rho = ti.field(f32)
        self.cross = ti.field(i32)
        self.acc = ti.field(f32)
        fb.dense(ti.ijkl, (19, nx, ny, nz)).place(self.f0)
        fb.dense(ti.ijkl, (19, nx, ny, nz)).place(self.f1)
        for fld in (self.flags, self.ux, self.uy, self.uz, self.rho):
            fb.dense(ti.ijk, (nx, ny, nz)).place(fld)
        fb.dense(ti.ijk, (nx + 1, ny, nz)).place(self.cross)
        fb.dense(ti.i, 4).place(self.acc)
        # 全フィールドを 1 本の SNodeTree にまとめ、格子変更時に destroy できるようにする
        self.tree = fb.finalize()
        self.cur = 0

    def release(self):
        if self.tree is not None:
            self.tree.destroy()
            self.tree = None

    # ------------------------------------------------------------ voxelize
    @ti.kernel
    def _vox_clear(self):
        for x, y, z in self.flags:
            self.flags[x, y, z] = ti.u8(0)
        for x, y, z in self.cross:
            self.cross[x, y, z] = 0

    @ti.kernel
    def _vox_surface(self, tris: ti.types.ndarray(dtype=f32, ndim=3)):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for t in range(tris.shape[0]):
            a = ti.Vector([tris[t, 0, 0], tris[t, 0, 1], tris[t, 0, 2]])
            b = ti.Vector([tris[t, 1, 0], tris[t, 1, 1], tris[t, 1, 2]])
            c = ti.Vector([tris[t, 2, 0], tris[t, 2, 1], tris[t, 2, 2]])
            e = ti.max((b - a).norm(), (c - a).norm(), (c - b).norm())
            n = ti.max(1, ti.cast(ti.ceil(e / 0.5), i32))
            for i in range(n + 1):
                for j in range(n + 1 - i):
                    p = a + (b - a) * (i / n) + (c - a) * (j / n)
                    x = ti.cast(ti.floor(p.x), i32); y = ti.cast(ti.floor(p.y), i32); z = ti.cast(ti.floor(p.z), i32)
                    if x >= 1 and x < nx - 1 and y >= 0 and y < ny and z >= 1 and z < nz - 1:
                        self.flags[x, y, z] = ti.u8(1)

    @ti.kernel
    def _vox_cross(self, tris: ti.types.ndarray(dtype=f32, ndim=3)):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for t in range(tris.shape[0]):
            x0, y0, z0 = tris[t, 0, 0], tris[t, 0, 1], tris[t, 0, 2]
            x1, y1, z1 = tris[t, 1, 0], tris[t, 1, 1], tris[t, 1, 2]
            x2, y2, z2 = tris[t, 2, 0], tris[t, 2, 1], tris[t, 2, 2]
            area = (y1 - y0) * (z2 - z0) - (z1 - z0) * (y2 - y0)
            if ti.abs(area) > 1e-9:
                ymin = ti.max(0, ti.cast(ti.floor(ti.min(y0, y1, y2)), i32)); ymax = ti.min(ny - 1, ti.cast(ti.ceil(ti.max(y0, y1, y2)), i32))
                zmin = ti.max(0, ti.cast(ti.floor(ti.min(z0, z1, z2)), i32)); zmax = ti.min(nz - 1, ti.cast(ti.ceil(ti.max(z0, z1, z2)), i32))
                for cy in range(ymin, ymax + 1):
                    for cz in range(zmin, zmax + 1):
                        py = cy + 0.5137; pz = cz + 0.5071
                        w0 = ((y1 - py) * (z2 - pz) - (z1 - pz) * (y2 - py)) / area
                        w1 = ((y2 - py) * (z0 - pz) - (z2 - pz) * (y0 - py)) / area
                        w2 = 1.0 - w0 - w1
                        if w0 >= 0 and w1 >= 0 and w2 >= 0:
                            x = w0 * x0 + w1 * x1 + w2 * x2
                            k = ti.cast(ti.ceil(x - 0.5), i32)
                            k = ti.max(0, ti.min(nx, k))
                            ti.atomic_add(self.cross[k, cy, cz], 1)

    @ti.kernel
    def _vox_fill(self) -> i32:
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        area = 0
        for y, z in ti.ndrange(ny, nz):
            cnt = 0
            has = 0
            for x in range(nx):
                cnt += self.cross[x, y, z]
                if x >= 1 and x <= nx - 2:
                    if cnt % 2 == 1:
                        self.flags[x, y, z] = ti.u8(1)
                    if self.flags[x, y, z] == ti.u8(1):
                        has = 1
            area += has
        return area

    @ti.kernel
    def _vox_walls(self, zlo: i32, zhi: i32, ylo: i32, yhi: i32) -> i32:
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        solid = 0
        for x, y, z in self.flags:
            if self.flags[x, y, z] == ti.u8(1):
                solid += 1
        for x, y in ti.ndrange(nx, ny):
            if zlo != 0:
                self.flags[x, y, 0] = ti.u8(zlo)
            if zhi != 0:
                self.flags[x, y, nz - 1] = ti.u8(zhi)
        for x, z in ti.ndrange(nx, nz):
            if ylo != 0:
                self.flags[x, 0, z] = ti.u8(ylo)
            if yhi != 0:
                self.flags[x, ny - 1, z] = ti.u8(yhi)
        return solid

    @ti.kernel
    def _force_rest(self):
        # 静止一様流体 (f = W) で運動量交換法が返す力 = 基準圧の寄与。取付面がある場合に非 0。
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for x, y, z in self.flags:
            if self.flags[x, y, z] != ti.u8(0):
                continue
            if x == 0 or x == nx - 1 or z == 0 or z == nz - 1:
                continue
            for i in ti.static(range(19)):
                sx = x - CX[i]
                sy = (y - CY[i] + ny) % ny
                sz = z - CZ[i]
                if self.flags[sx, sy, sz] == ti.u8(1):
                    o = ti.static(OPP[i])
                    self.acc[0] += 2.0 * W[o] * CX[o]
                    self.acc[1] += 2.0 * W[o] * CY[o]
                    self.acc[2] += 2.0 * W[o] * CZ[o]

    @ti.kernel
    def _init_f(self):
        for x, y, z in self.flags:
            for i in ti.static(range(19)):
                self.f0[i, x, y, z] = W[i]
                self.f1[i, x, y, z] = W[i]
            self.ux[x, y, z] = 0.0; self.uy[x, y, z] = 0.0; self.uz[x, y, z] = 0.0; self.rho[x, y, z] = 1.0

    def prepare(self, nx, ny, nz, tris, walls):
        self._alloc(nx, ny, nz)
        tris = np.ascontiguousarray(tris, dtype=np.float32)
        self._vox_clear()
        self._vox_surface(tris)
        self._vox_cross(tris)
        area = int(self._vox_fill())
        solid = int(self._vox_walls(int(walls.get("zlo", 0)), int(walls.get("zhi", 0)), int(walls.get("ylo", 0)), int(walls.get("yhi", 0))))
        self._init_f()
        self._zero_acc(); self._force_rest()
        self.F0 = self.acc.to_numpy()[:3].astype(np.float64)
        self.set_params(0.5, 0.0, 0.1, 0)
        ti.sync()
        return {"solid": solid, "area": area}

    def set_params(self, tau0, uin, cs, ground):
        self.tau0, self.uin, self.cs, self.ground = float(tau0), float(uin), float(cs), int(ground)

    # ------------------------------------------------------------ step
    @ti.func
    def _feq(self, i: ti.template(), rho, u):
        cu = CX[i] * u.x + CY[i] * u.y + CZ[i] * u.z
        return W[i] * rho * (1.0 + 3.0 * cu + 4.5 * cu * cu - 1.5 * u.dot(u))

    @ti.kernel
    def _step(self, src: ti.template(), dst: ti.template(), tau0: f32, uin: f32, cs: f32, ground: i32):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        uinv = ti.Vector([uin, 0.0, 0.0])
        for x, y, z in self.flags:
            if self.flags[x, y, z] != ti.u8(0):
                continue
            if x == 0 or z == nz - 1 or (z == 0 and ground == 0):
                for i in ti.static(range(19)):
                    dst[i, x, y, z] = self._feq(i, 1.0, uinv)
                self.ux[x, y, z] = uin; self.uy[x, y, z] = 0.0; self.uz[x, y, z] = 0.0; self.rho[x, y, z] = 1.0
                continue
            if x == nx - 1:
                r = 0.0
                m = ti.Vector([0.0, 0.0, 0.0])
                for i in ti.static(range(19)):
                    v = src[i, x - 1, y, z]
                    dst[i, x, y, z] = v
                    r += v
                    m += v * ti.Vector([CX[i], CY[i], CZ[i]])
                self.ux[x, y, z] = m.x / r; self.uy[x, y, z] = m.y / r; self.uz[x, y, z] = m.z / r; self.rho[x, y, z] = r
                continue
            f = ti.Vector.zero(f32, 19)
            force = ti.Vector([0.0, 0.0, 0.0])
            for i in ti.static(range(19)):
                sx = x - CX[i]
                sy = (y - CY[i] + ny) % ny
                sz = z - CZ[i]
                nf = self.flags[sx, sy, sz]
                if nf == ti.u8(0):
                    f[i] = src[i, sx, sy, sz]
                else:
                    o = ti.static(OPP[i])
                    fo = src[o, x, y, z]
                    co = ti.Vector([CX[o], CY[o], CZ[o]])
                    if nf == ti.u8(1):
                        f[i] = fo
                        force += 2.0 * fo * co
                    elif nf == ti.u8(2):
                        f[i] = fo - 6.0 * W[o] * (co.x * uin)
                    elif nf == ti.u8(3):
                        f[i] = fo
                    else:
                        if sz == 0 or sz == nz - 1:
                            f[i] = src[ti.static(REFL_Z[i]), x, y, z]
                        else:
                            f[i] = src[ti.static(REFL_Y[i]), x, y, z]
            rho = 0.0
            m = ti.Vector([0.0, 0.0, 0.0])
            for i in ti.static(range(19)):
                rho += f[i]
                m += f[i] * ti.Vector([CX[i], CY[i], CZ[i]])
            u = m / rho
            us = u.dot(u)
            if us > 0.09:
                u = u * (0.3 / ti.sqrt(us))
            pxx = 0.0; pyy = 0.0; pzz = 0.0; pxy = 0.0; pxz = 0.0; pyz = 0.0
            fe = ti.Vector.zero(f32, 19)
            for i in ti.static(range(19)):
                fe[i] = self._feq(i, rho, u)
                d = f[i] - fe[i]
                pxx += CX[i] * CX[i] * d; pyy += CY[i] * CY[i] * d; pzz += CZ[i] * CZ[i] * d
                pxy += CX[i] * CY[i] * d; pxz += CX[i] * CZ[i] * d; pyz += CY[i] * CZ[i] * d
            Q = ti.sqrt(2.0 * (pxx * pxx + pyy * pyy + pzz * pzz + 2.0 * (pxy * pxy + pxz * pxz + pyz * pyz)))
            tau = 0.5 * (tau0 + ti.sqrt(tau0 * tau0 + 18.0 * cs * cs * Q / rho))
            om = 1.0 / tau
            for i in ti.static(range(19)):
                dst[i, x, y, z] = f[i] - om * (f[i] - fe[i])
            self.ux[x, y, z] = u.x; self.uy[x, y, z] = u.y; self.uz[x, y, z] = u.z; self.rho[x, y, z] = rho
            self.acc[0] += force.x; self.acc[1] += force.y; self.acc[2] += force.z

    def step(self, k=1):
        for _ in range(k):
            self._zero_acc()
            if self.cur == 0:
                self._step(self.f0, self.f1, self.tau0, self.uin, self.cs, self.ground)
            else:
                self._step(self.f1, self.f0, self.tau0, self.uin, self.cs, self.ground)
            self.cur ^= 1

    @ti.kernel
    def _zero_acc(self):
        for i in range(4):
            self.acc[i] = 0.0

    def get_force(self):
        a = self.acc.to_numpy()[:3] - self.F0
        return [float(a[0]), float(a[1]), float(a[2])]

    # ------------------------------------------------------------ sampling
    @ti.kernel
    def _slice(self, out: ti.types.ndarray(dtype=f32, ndim=2), axis: i32, k: i32, mode: i32, uin: f32):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for a, b in ti.ndrange(out.shape[0], out.shape[1]):
            x = a; y = b; z = k
            if axis == 1:
                x = a; y = k; z = b
            elif axis == 0:
                x = k; y = a; z = b
            v = 0.0
            if self.flags[x, y, z] == ti.u8(1):
                v = ti.math.nan
            elif mode == 0:
                v = ti.sqrt(self.ux[x, y, z] ** 2 + self.uy[x, y, z] ** 2 + self.uz[x, y, z] ** 2) / uin
            elif mode == 1:
                v = self.ux[x, y, z] / uin
            else:
                v = ((self.rho[x, y, z] - 1.0) / 3.0) / (0.5 * uin * uin)
            out[a, b] = v

    def slice(self, axis, pos, field, uin):
        nx, ny, nz = self.nx, self.ny, self.nz
        if axis == "z":
            k = min(nz - 1, int(pos * nz)); out = np.empty((nx, ny), np.float32); ax = 2
        elif axis == "y":
            k = min(ny - 1, int(pos * ny)); out = np.empty((nx, nz), np.float32); ax = 1
        else:
            k = min(nx - 1, int(pos * nx)); out = np.empty((ny, nz), np.float32); ax = 0
        self._slice(out, ax, k, {"u": 0, "ux": 1, "cp": 2}[field], float(uin))
        return out

    @ti.kernel
    def _coarse(self, out: ti.types.ndarray(dtype=f32, ndim=4), s: i32):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for a, b, c in ti.ndrange(out.shape[0], out.shape[1], out.shape[2]):
            x = ti.min(nx - 1, a * s); y = ti.min(ny - 1, b * s); z = ti.min(nz - 1, c * s)
            if self.flags[x, y, z] == ti.u8(1):
                out[a, b, c, 0] = 0.0; out[a, b, c, 1] = 0.0; out[a, b, c, 2] = 0.0
            else:
                out[a, b, c, 0] = self.ux[x, y, z]; out[a, b, c, 1] = self.uy[x, y, z]; out[a, b, c, 2] = self.uz[x, y, z]

    def coarse(self, maxdim):
        s = max(1, int(math.ceil(max(self.nx, self.ny, self.nz) / maxdim)))
        cx, cy, cz = (self.nx + s - 1) // s, (self.ny + s - 1) // s, (self.nz + s - 1) // s
        out = np.empty((cx, cy, cz, 3), np.float32)
        self._coarse(out, s)
        return out, s

    @ti.kernel
    def _cp(self, verts: ti.types.ndarray(dtype=f32, ndim=2), normals: ti.types.ndarray(dtype=f32, ndim=2), out: ti.types.ndarray(dtype=f32, ndim=1), uin: f32):
        nx, ny, nz = ti.static(self.nx), ti.static(self.ny), ti.static(self.nz)
        for v in range(verts.shape[0]):
            out[v] = ti.math.nan
            found = 0
            for d in ti.static([1.5, 2.5, 3.5]):
                for sg in ti.static([1.0, -1.0]):
                    if found == 0:
                        x = ti.cast(ti.floor(verts[v, 0] + sg * d * normals[v, 0]), i32)
                        y = ti.cast(ti.floor(verts[v, 1] + sg * d * normals[v, 1]), i32)
                        z = ti.cast(ti.floor(verts[v, 2] + sg * d * normals[v, 2]), i32)
                        if x >= 1 and x < nx - 1 and y >= 0 and y < ny and z >= 1 and z < nz - 1:
                            if self.flags[x, y, z] == ti.u8(0):
                                out[v] = ((self.rho[x, y, z] - 1.0) / 3.0) / (0.5 * uin * uin)
                                found = 1

    def cp(self, verts, normals, uin):
        out = np.empty(len(verts), np.float32)
        self._cp(np.ascontiguousarray(verts, np.float32), np.ascontiguousarray(normals, np.float32), out, float(uin))
        return out
