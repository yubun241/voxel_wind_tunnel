"""D3Q19 の定数。Taichi / NumPy 両実装で共有する。"""
import numpy as np

CX = [0, 1, -1, 0, 0, 0, 0, 1, -1, 1, -1, 1, -1, 1, -1, 0, 0, 0, 0]
CY = [0, 0, 0, 1, -1, 0, 0, 1, -1, -1, 1, 0, 0, 0, 0, 1, -1, 1, -1]
CZ = [0, 0, 0, 0, 0, 1, -1, 0, 0, 0, 0, 1, -1, -1, 1, 1, -1, -1, 1]
W = [1 / 3] + [1 / 18] * 6 + [1 / 36] * 12


def _find(cx, cy, cz):
    for j in range(19):
        if CX[j] == cx and CY[j] == cy and CZ[j] == cz:
            return j
    raise ValueError


OPP = [_find(-CX[i], -CY[i], -CZ[i]) for i in range(19)]
REFL_Y = [_find(CX[i], -CY[i], CZ[i]) for i in range(19)]   # y 法線の鏡面反射
REFL_Z = [_find(CX[i], CY[i], -CZ[i]) for i in range(19)]   # z 法線の鏡面反射

C = np.array([CX, CY, CZ], dtype=np.float32).T   # (19,3)
W_NP = np.array(W, dtype=np.float32)

# フラグ
FLUID, BODY, BELT, WALL, SLIP = 0, 1, 2, 3, 4
