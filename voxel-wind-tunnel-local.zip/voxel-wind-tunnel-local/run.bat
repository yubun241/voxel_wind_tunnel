@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title ボクセル風洞 ローカル版

rem ---- Python 3.10〜3.12 を探す (Taichi の対応範囲)
set "PY="
for %%v in (3.11 3.12 3.10) do (
  if not defined PY ( py -%%v -c "import sys" >nul 2>&1 && set "PY=py -%%v" )
)
if not defined PY ( python -c "import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<=(3,12) else 1)" >nul 2>&1 && set "PY=python" )
if not defined PY (
  echo.
  echo Python 3.10 - 3.12 が見つかりません。
  echo https://www.python.org/downloads/ から Python 3.11 をインストールしてください。
  echo インストーラで "Add python.exe to PATH" にチェックを入れてください。
  echo.
  pause
  exit /b 1
)

rem ---- 仮想環境 (このフォルダ内に閉じる)
if not exist ".venv\Scripts\python.exe" (
  echo 初回セットアップ: 仮想環境を作成しています...
  %PY% -m venv .venv || ( echo 仮想環境の作成に失敗しました。 & pause & exit /b 1 )
)
set "VPY=.venv\Scripts\python.exe"
if not exist ".venv\.installed" (
  echo 依存パッケージをインストールしています (初回のみ、数分かかります)...
  "%VPY%" -m pip install --upgrade pip --quiet
  "%VPY%" -m pip install -r requirements.txt || ( echo NumPy のインストールに失敗しました。ネットワークを確認してください。 & pause & exit /b 1 )
  "%VPY%" -m pip install -r requirements-gpu.txt || echo Taichi のインストールに失敗しました。NumPy 実装 (低速) で動作します。
  echo ok > ".venv\.installed"
)

"%VPY%" -m voxeltunnel %*
echo.
pause
