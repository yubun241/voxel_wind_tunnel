#!/usr/bin/env bash
# ボクセル風洞 ローカル版 — Linux / macOS 用起動スクリプト (macOS は run.command をダブルクリック)
set -u
cd "$(dirname "$0")"

PY=""
for c in python3.11 python3.12 python3.10 python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; raise SystemExit(0 if (3,10)<=sys.version_info[:2]<=(3,12) else 1)' 2>/dev/null; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3.10〜3.12 が見つかりません。"
  echo "  macOS : brew install python@3.11   または https://www.python.org/downloads/"
  echo "  Linux : sudo apt install python3.11 python3.11-venv  (Debian/Ubuntu)"
  read -r -p "Enter で終了" _; exit 1
fi

if [ ! -x ".venv/bin/python" ]; then
  echo "初回セットアップ: 仮想環境を作成しています..."
  "$PY" -m venv .venv || { echo "仮想環境の作成に失敗しました (python3-venv が必要な場合があります)"; read -r -p "Enter で終了" _; exit 1; }
fi
VPY=".venv/bin/python"
if [ ! -f ".venv/.installed" ]; then
  echo "依存パッケージをインストールしています (初回のみ、数分かかります)..."
  "$VPY" -m pip install --upgrade pip --quiet
  "$VPY" -m pip install -r requirements.txt || { echo "NumPy のインストールに失敗しました。"; read -r -p "Enter で終了" _; exit 1; }
  "$VPY" -m pip install -r requirements-gpu.txt || echo "Taichi のインストールに失敗しました。NumPy 実装 (低速) で動作します。"
  echo ok > .venv/.installed
fi

"$VPY" -m voxeltunnel "$@"
