# ボクセル風洞 ローカル版

STL を読み込み、**この PC の GPU / CPU** で格子ボルツマン法 (D3Q19 + Smagorinsky LES) を回して、
流れの可視化と Cd / Cl / ダウンフォースの A/B 比較を行います。操作画面はブラウザ、計算は Python (Taichi) です。

## 使い方 (3 ステップ)

1. この zip を展開する (日本語を含まないパスが安全: 例 `C:\tools\voxel-wind-tunnel`)
2. 起動スクリプトをダブルクリック
   - Windows: `run.bat`
   - macOS: `run.command` (初回は右クリック → 開く)
   - Linux: `./run.sh`
3. 自動でブラウザが開き、Ahmed body が回り始めます。あとは「STL を読み込む」から自分の部品へ。

初回だけ、このフォルダ内に Python 仮想環境 (`.venv`) を作って依存パッケージをインストールします (数分、ネットワーク必要)。
2 回目以降はオフラインで起動できます (Three.js は初回にフォルダへ同梱されます)。

### 必要なもの
- **Python 3.10〜3.12** (3.13 は計算エンジン Taichi が未対応)。無ければ https://www.python.org/downloads/ から 3.11 を。Windows はインストーラで "Add python.exe to PATH" にチェック。
- ブラウザ (Chrome / Edge / Firefox / Safari どれでも。WebGPU は不要)

## ハードウェアの自動判定

起動時に次の順で試し、使えたものを採用します。

| 順 | バックエンド | 対象 | メモリ |
|---|---|---|---|
| 1 | CUDA | NVIDIA GPU | VRAM (nvidia-smi で空き容量を取得) |
| 2 | Vulkan | AMD / Intel / NVIDIA GPU | VRAM (取得できない場合は 4 GB と仮定) |
| 3 | Metal | Apple Silicon | ユニファイドメモリ |
| 4 | CPU | マルチコア (全スレッド) | 空き RAM |
| 5 | NumPy | Taichi が使えない環境 | 空き RAM (低速) |

計算に使えるメモリの 70 % を上限として、1 セル約 170 B で格子の上限を決め、画面の「解像度」に選択肢として出します。
画面上部のチップに `CUDA / RTX 4090` のように採用結果が表示されます。

手動で変えたいとき:
```
run.bat --arch cpu            # CPU で回す
run.bat --mem-gb 8            # メモリ上限を 8 GB とみなす
run.bat --arch vulkan --port 9000
```

### 目安の性能 (D3Q19, 1 ステップ = 全セル更新)
| 環境 | 速度 | 256×128×128 (4.2M cells) で 1 流過 (約 5,000 steps) |
|---|---|---|
| RTX 4090 (CUDA) | 1,500〜3,000 MLUPS | 10〜15 秒 |
| RTX 3060 / Radeon 7700 | 400〜800 MLUPS | 30〜60 秒 |
| M2 Pro (Metal) | 300〜500 MLUPS | 1 分前後 |
| 16 コア CPU | 30〜80 MLUPS | 5〜10 分 |
| NumPy | 1〜3 MLUPS | 実用外 (128×64×64 で数分) |

GPU の数値は Taichi の一般的な実績からの推定で、実測ではありません。

## ブラウザ版との違い

| | ブラウザ版 (GitHub Pages) | ローカル版 |
|---|---|---|
| 計算場所 | ブラウザ内 WebGPU | この PC の GPU / CPU (Taichi) |
| 格子上限 | 256³ 程度 (ブラウザのバッファ制限) | VRAM / RAM 次第。24 GB VRAM なら 640×320×320 (65M cells) |
| ボクセル化 | ブラウザ (JS) | サーバ側 (GPU カーネル)。大きな STL でも固まらない |
| ブラウザへ送るもの | 全フィールド | 断面 (2D)、間引き速度場 (≤96³)、表面 Cp のみ |
| データ | タブ内メモリ | この PC 内。外部送信なし (サーバは 127.0.0.1 のみ待ち受け) |
| 比較表 | メモリのみ | ブラウザの localStorage (同じ PC で持ち越し) |

物理モデル・境界条件・力の評価は同じです。同じ格子なら同じ結果になります。

## 取付面 (壁密着) の扱い

「境界・取付」で底面 / 上面 / 側面を壁に密着させると、その面は流体に触れません。
壁に埋まった面があると、LBM の基準圧 (ρ₀/3) が露出面にだけ掛かって巨大な法線力が出るため、
準備時に「静止流体での運動量交換力」を測って差し引いています (閉じた物体ではこの補正は厳密に 0)。

## 構成

```
run.bat / run.sh / run.command   起動スクリプト (venv 作成 → 依存インストール → サーバ起動 → ブラウザ)
requirements.txt                 numpy
requirements-gpu.txt             taichi (失敗しても NumPy で起動)
voxeltunnel/
  __main__.py      エントリ。ハードウェア判定 → サーバ → ブラウザ起動
  hardware.py      CUDA / Vulkan / Metal / CPU の判定とメモリ量の取得
  lattice.py       D3Q19 定数
  solver_taichi.py Taichi 実装 (ボクセル化 / LBM / 力 / 断面・間引き場・Cp の抽出)
  solver_numpy.py  NumPy 実装 (参照・フォールバック)
  voxel_np.py      NumPy ボクセライザ
  server.py        HTTP API (標準ライブラリのみ)。ソルバは 1 スレッドが所有
  static/index.html  操作画面 (ブラウザ版から生成)
build_static.py    ブラウザ版 HTML から static/index.html を再生成するスクリプト
```

### API (他のツールから叩く場合)
| メソッド | パス | 内容 |
|---|---|---|
| GET | `/api/hardware` | バックエンド・メモリ・格子プリセット |
| POST | `/api/prepare?nx&ny&nz&zlo&zhi&ylo&yhi` | body = 格子座標の三角形 (float32 × 9 × N)。ボクセル化して返す |
| POST | `/api/params` | `{tau0, uin, cs, ground, spf}` |
| POST | `/api/run?on=1/0` | 開始 / 一時停止 |
| GET | `/api/status?since=N` | ステップ数、速度、力の履歴 (N 以降) |
| GET | `/api/slice?axis&pos&field&uin` | 2D float32 (固体は NaN)。`X-Dims` ヘッダに寸法 |
| GET | `/api/coarse?maxdim` | 間引き速度場 float32 (cx,cy,cz,3)。`X-Stride` |
| GET | `/api/cp?uin` | 頂点ごとの Cp |

## トラブルシューティング
- **ブラウザが開かない**: スクリプトのウィンドウに表示される URL (`http://127.0.0.1:8765/`) を手で開く。
- **`CUDA: 利用不可`**: NVIDIA ドライバを更新。それでも駄目なら `--arch vulkan`。
- **発散しました**: τ 下限を 0.505〜0.51 に上げる、u_lb を 0.03 に下げる、解像度を上げる。
- **Taichi のインストールに失敗**: Python が 3.13 以上の可能性。3.11 を入れて `.venv` フォルダを削除し再実行。
- **Windows で文字化け**: `run.bat` は UTF-8 (chcp 65001) で動きます。古い `cmd` では表示だけ崩れますが動作には影響しません。
