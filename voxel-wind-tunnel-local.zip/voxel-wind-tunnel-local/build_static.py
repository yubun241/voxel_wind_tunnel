"""ブラウザ版 (voxel-wind-tunnel.html) からローカル版 static/index.html を生成する。

共有部分 (UI / STL / 配置 / 描画 / 読み出し) はそのまま使い、
WebGPU ソルバとフィールド依存の可視化だけをローカル API 版に置き換える。
"""
import re
import sys
from pathlib import Path

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else "../voxel-wind-tunnel.html")
DST = Path(__file__).parent / "voxeltunnel" / "static" / "index.html"
s = SRC.read_text(encoding="utf-8")


def section(name):
    """'// ---- name' から次の '// ----' マーカー直前までを返す (正規表現)。"""
    return re.compile(r"// -{10,} " + re.escape(name) + r"\n.*?(?=\n// -{10,} |\n</script>)", re.S)


def replace_section(name, new):
    global s
    m = section(name).search(s)
    assert m, name
    s = s[:m.start()] + f"// ---------------------------------------------------------------- {name}\n" + new.strip("\n") + s[m.end():]


def sub(a, b, count=1):
    global s
    assert a in s, a[:80]
    s = s.replace(a, b, count)


# ---------------------------------------------------------------- 文書の体裁
head = '''<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
'''
sub('<title>ボクセル風洞</title>', head + '<title>ボクセル風洞 ローカル</title>')
sub('<style>\n/* Layout', '<style>\nhtml{color-scheme:dark}\n/* Layout')
sub('</style>\n\n<div id="app">', '</style>\n</head>\n<body>\n<div id="app">')
s = s.rstrip() + '\n</body>\n</html>\n'

# ---------------------------------------------------------------- ヘッダ
sub('<h1>ボクセル風洞</h1>', '<h1>ボクセル風洞 <span style="font-weight:400;color:var(--muted)">ローカル</span></h1>')
sub('<span class="sub">STL → ボクセル → 格子ボルツマン法 (D3Q19 + Smagorinsky, WebGPU)</span>',
    '<span class="sub">STL → ボクセル → 格子ボルツマン法 (D3Q19 + Smagorinsky) をこの PC の GPU / CPU で計算</span>')
sub('<span id="gpuChip" class="chip">GPU 確認中</span>', '<span id="gpuChip" class="chip">接続中…</span><span id="memChip" class="chip mono"></span>')
sub('<div id="msg">WebGPU を初期化中…</div>', '<div id="msg">ローカルサーバに接続中…</div>')
sub('<div class="row"><label for="spf">ステップ / フレーム</label>', '<div class="row"><label for="spf">ステップ / バッチ</label>')
sub('value="4" min="1" max="32" step="1"></div></div>\n        <p class="hint" id="prepHint">', 'value="8" min="1" max="64" step="1"></div></div>\n        <p class="hint" id="prepHint">')
# 格子セレクトは起動時にハードウェアから生成
sub(re.search(r'<select id="grid">.*?</select>', s, re.S).group(0), '<select id="grid"></select>')

# ---------------------------------------------------------------- three.js: 同梱があればそれ、無ければ CDN
sub("import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.165.0/build/three.module.js';",
    "const THREE = await import('./vendor/three.module.js').catch(() => import('https://cdn.jsdelivr.net/npm/three@0.165.0/build/three.module.js'));")

# ---------------------------------------------------------------- ボクセル化はサーバ側
replace_section("voxelize", """
// ボクセル化はローカルサーバ (Taichi / NumPy) 側で行う。ブラウザは格子座標の三角形を送るだけ。
""")

# ---------------------------------------------------------------- ソルバ → HTTP API
replace_section("WebGPU solver", """
// ローカルサーバ API。計算はこの PC の GPU / CPU で走り、ブラウザは断面・間引き場・表面 Cp だけ受け取る。
async function api(path, opt) {
  const r = await fetch(path, opt);
  if (!r.ok) { let m = ''; try { m = (await r.json()).error || ''; } catch {} throw new Error(m || `${r.status} ${r.statusText}`); }
  return r;
}
const apiJSON = async (path, opt) => (await api(path, opt)).json();
async function apiBin(path) {
  const r = await api(path);
  return { buf: new Float32Array(await r.arrayBuffer()), dims: (r.headers.get('X-Dims') || '').split(',').map(Number), stride: +(r.headers.get('X-Stride') || 1) };
}
async function sendParams() {
  if (!S.prepared) return;
  const ramp = Math.min(1, S.step / RAMP);
  const body = { tau0: S.tau0, uin: S.uin * ramp, cs: +$('cs').value, ground: boundaryConfig().hasGround ? 1 : 0, spf: +$('spf').value };
  const key = JSON.stringify(body);
  if (key === S.lastParams) return;
  S.lastParams = key;
  await apiJSON('/api/params', { method: 'POST', body: key }).catch(() => {});
}
""")

# ---------------------------------------------------------------- 流線: 間引き場
sub(re.search(r"// 流線: 中心格子のトリリニア補間を RK2 で積分\nfunction sampleU\(.*?\n\}\n", s, re.S).group(0), """// 流線: サーバから受け取った間引き速度場 (stride s) をトリリニア補間し RK2 で積分
function sampleU(C, x, y, z, out) {
  const [cx, cy, cz] = C.dims, s = C.stride, d = C.buf;
  const fx = Math.min(cx - 1.001, Math.max(0, (x - 0.5) / s)), fy = Math.min(cy - 1.001, Math.max(0, (y - 0.5) / s)), fz = Math.min(cz - 1.001, Math.max(0, (z - 0.5) / s));
  const i = fx | 0, j = fy | 0, k = fz | 0, a = fx - i, b = fy - j, c = fz - k;
  out[0] = out[1] = out[2] = 0;
  for (let dk = 0; dk < 2; dk++) for (let dj = 0; dj < 2; dj++) for (let di = 0; di < 2; di++) {
    const w = (di ? a : 1 - a) * (dj ? b : 1 - b) * (dk ? c : 1 - c);
    const o = 3 * (((i + di) * cy + (j + dj)) * cz + (k + dk));
    out[0] += w * d[o]; out[1] += w * d[o + 1]; out[2] += w * d[o + 2];
  }
}
""")
sub("""  if (!mac || !$('showStream').checked || !S.latBox) return;
  const { nx, ny, nz, flags } = S, b = S.latBox;""",
    """  if (!mac || !$('showStream').checked || !S.latBox) return;
  const { nx, ny, nz } = S, b = S.latBox;""")
sub("""      if (flags[(x | 0) + nx * ((y | 0) + ny * (z | 0))] === 1) break;
      sampleU(mac, x, y, z, u);""",
    """      sampleU(mac, x, y, z, u);""")

# ---------------------------------------------------------------- 断面: サーバの 2D 配列
sub(re.search(r"function fieldValue\(mac, o, mode\) \{.*?\n\}\n", s, re.S).group(0), "")
sub("""function buildSlice(mac) {
  if (sliceMesh) { inner.remove(sliceMesh); sliceMesh.geometry.dispose(); sliceMesh = null; }
  if (sliceTex) { sliceTex.dispose(); sliceTex = null; }
  const axis = $('sliceAxis').value; if (axis === 'none') return;
  const { nx, ny, nz, flags } = S, mode = $('field').value, [lo, hi] = FIELD_RANGE[mode];""",
    """function buildSlice(sl) {
  if (sliceMesh) { inner.remove(sliceMesh); sliceMesh.geometry.dispose(); sliceMesh = null; }
  if (sliceTex) { sliceTex.dispose(); sliceTex = null; }
  const axis = sl && sl.axis; if (!sl || axis === 'none') return;
  const { nx, ny, nz } = S, mode = sl.field, [lo, hi] = FIELD_RANGE[mode];""")
sub("""  const t = +$('slicePos').value;
  let w, hgt, idxOf, geom, pos;
  if (axis === 'z') { const k = Math.min(nz - 1, Math.floor(t * nz)); w = nx; hgt = ny; idxOf = (a, b) => a + nx * (b + ny * k); geom = new THREE.PlaneGeometry(nx, ny); pos = [nx / 2, ny / 2, k + 0.5]; }
  else if (axis === 'y') { const k = Math.min(ny - 1, Math.floor(t * ny)); w = nx; hgt = nz; idxOf = (a, b) => a + nx * (k + ny * b); geom = new THREE.PlaneGeometry(nx, nz); geom.applyMatrix4(new THREE.Matrix4().set(1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1)); pos = [nx / 2, k + 0.5, nz / 2]; }
  else { const k = Math.min(nx - 1, Math.floor(t * nx)); w = ny; hgt = nz; idxOf = (a, b) => k + nx * (a + ny * b); geom = new THREE.PlaneGeometry(ny, nz); geom.applyMatrix4(new THREE.Matrix4().set(0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1)); pos = [k + 0.5, ny / 2, nz / 2]; }
  const data = new Uint8Array(w * hgt * 4);
  for (let b = 0; b < hgt; b++) for (let a = 0; a < w; a++) {
    const id = idxOf(a, b), p = 4 * (a + w * b);
    if (flags[id] === 1) { data[p] = data[p + 1] = data[p + 2] = 40; data[p + 3] = 255; continue; }
    const v = fieldValue(mac, 4 * id, mode), c = cmap((v - lo) / (hi - lo));
    data[p] = c[0] * 255; data[p + 1] = c[1] * 255; data[p + 2] = c[2] * 255; data[p + 3] = 235;
  }""",
    """  const t = sl.pos, [w, hgt] = sl.dims;
  let geom, pos;
  if (axis === 'z') { const k = Math.min(nz - 1, Math.floor(t * nz)); geom = new THREE.PlaneGeometry(nx, ny); pos = [nx / 2, ny / 2, k + 0.5]; }
  else if (axis === 'y') { const k = Math.min(ny - 1, Math.floor(t * ny)); geom = new THREE.PlaneGeometry(nx, nz); geom.applyMatrix4(new THREE.Matrix4().set(1, 0, 0, 0, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 1)); pos = [nx / 2, k + 0.5, nz / 2]; }
  else { const k = Math.min(nx - 1, Math.floor(t * nx)); geom = new THREE.PlaneGeometry(ny, nz); geom.applyMatrix4(new THREE.Matrix4().set(0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1)); pos = [k + 0.5, ny / 2, nz / 2]; }
  const data = new Uint8Array(w * hgt * 4);
  for (let b = 0; b < hgt; b++) for (let a = 0; a < w; a++) {
    const v = sl.buf[a * hgt + b], p = 4 * (a + w * b);
    if (Number.isNaN(v)) { data[p] = data[p + 1] = data[p + 2] = 40; data[p + 3] = 255; continue; }
    const c = cmap((v - lo) / (hi - lo));
    data[p] = c[0] * 255; data[p + 1] = c[1] * 255; data[p + 2] = c[2] * 255; data[p + 3] = 235;
  }""")

# ---------------------------------------------------------------- 表面 Cp: サーバの頂点配列
sub(re.search(r"function colorSurfaceCp\(mac\) \{.*?\n\}\n", s, re.S).group(0), """function colorSurfaceCp(cp) {
  if (!modelMesh) return;
  const col = modelMesh.geometry.attributes.color.array;
  const on = $('showCp').checked && cp && cp.length * 3 === col.length;
  if (!on) { col.fill(0.7); modelMesh.geometry.attributes.color.needsUpdate = true; return; }
  for (let v = 0; v < cp.length; v++) {
    const o = v * 3, val = cp[v];
    if (Number.isNaN(val)) { col[o] = col[o + 1] = col[o + 2] = 0.5; continue; }
    const c = cmap((val + 2) / 3);
    col[o] = c[0]; col[o + 1] = c[1]; col[o + 2] = c[2];
  }
  modelMesh.geometry.attributes.color.needsUpdate = true;
}
""")

# ---------------------------------------------------------------- prep / run / poll
replace_section("prep / run", """
async function prep() {
  if (!S.tris) { setHint('prepHint', 'まずモデルを読み込んでください。', 'bad'); return; }
  S.prepping = true;
  try { await prepInner(); } finally { S.prepping = false; }
}
async function prepInner() {
  await stop();
  [S.nx, S.ny, S.nz] = $('grid').value.split(',').map(Number);
  setHint('prepHint', 'ボクセル化中 (サーバ側)…');
  if (!placeModel()) return;
  const B = boundaryConfig();
  const q = `nx=${S.nx}&ny=${S.ny}&nz=${S.nz}&zlo=${B.zlo}&zhi=${B.zhi}&ylo=${B.ylo}&yhi=${B.yhi}`;
  let r;
  try { r = await apiJSON('/api/prepare?' + q, { method: 'POST', body: S.lat }); }
  catch (e) { setHint('prepHint', '準備に失敗: ' + e.message, 'bad'); return; }
  S.areaCells = r.area; S.prepared = true; S.flags = true; S.lastParams = '';
  S.step = 0; S.hist = []; S.vis = null;
  computeScaling();
  const minLen = Math.min(...S.latBox.len);
  setHint('prepHint', `固体セル ${r.solid.toLocaleString()} / 前面投影 ${r.area.toLocaleString()} cells / ボクセル化 ${r.ms.toFixed(0)} ms` + (minLen < 6 ? `  ⚠ 最小厚み ${minLen.toFixed(1)} cells。薄すぎます。解像度を上げるか占有率を上げてください。` : ''), minLen < 6 ? 'warn' : '');
  buildDomain(S.needCam); S.needCam = false; buildModelMesh();
  if (streamLines) { inner.remove(streamLines); streamLines = null; }
  if (sliceMesh) { inner.remove(sliceMesh); sliceMesh = null; }
  colorSurfaceCp(null);
  await sendParams();
  $('btnRun').disabled = false; $('btnReset').disabled = false;
  updateReadouts();
}
let previewQueued = false;
function preview() {
  if (!S.tris || previewQueued) return;
  previewQueued = true;
  requestAnimationFrame(() => {
    previewQueued = false;
    if (S.prepping) return;
    stop();
    [S.nx, S.ny, S.nz] = $('grid').value.split(',').map(Number);
    if (!placeModel()) return;
    S.flags = null; S.prepared = false; S.vis = null; S.hist = [];
    if (streamLines) { inner.remove(streamLines); streamLines = null; }
    if (sliceMesh) { inner.remove(sliceMesh); sliceMesh = null; }
    buildDomain(S.needCam); S.needCam = false; buildModelMesh(); colorSurfaceCp(null);
    $('btnRun').disabled = true; $('btnReset').disabled = true;
    setHint('prepHint', '配置を変更しました。「準備」で再ボクセル化してください。', 'warn');
    updateReadouts();
  });
}
async function start() {
  if (!S.prepared) return;
  await sendParams();
  await apiJSON('/api/run?on=1', { method: 'POST' }).catch(e => setHint('prepHint', e.message, 'bad'));
  S.running = true; $('btnRun').textContent = '❚❚ 一時停止'; $('runChip').textContent = '計算中'; $('runChip').className = 'chip run';
}
async function stop() {
  S.running = false; $('btnRun').textContent = '▶ 実行'; $('runChip').textContent = '停止'; $('runChip').className = 'chip';
  if (S.prepared) await apiJSON('/api/run?on=0', { method: 'POST' }).catch(() => {});
}
function setHint(id, t, cls = '') { $(id).textContent = t; $(id).className = 'hint ' + cls; }

const RAMP = 400, FIELD_MS = 500, POLL_MS = 200;
function frame() { requestAnimationFrame(frame); renderer.render(scene, camera); }
function refAreaCells() { return $('areaMode').value === 'auto' ? S.areaCells : (+$('area').value) / (S.dx * S.dx); }

// サーバの状態を定期取得。力の履歴は差分だけ受け取る。
async function poll() {
  if (!S.prepared || S.polling) return;
  S.polling = true;
  try {
    const st = await apiJSON('/api/status?since=' + S.hist.length);
    S.step = st.step;
    $('rateChip').textContent = Math.round(st.rate) + ' steps/s';
    const A = refAreaCells() || 1, qd = 0.5 * S.uin * S.uin * A;
    for (const h of st.hist) S.hist.push({ step: h.step, cd: h.F[0] / qd, cl: h.F[2] / qd, cy: h.F[1] / qd, F: h.F });
    if (st.error) { S.running = false; $('btnRun').textContent = '▶ 実行'; $('runChip').textContent = '停止'; $('runChip').className = 'chip'; setHint('prepHint', st.error, 'bad'); }
    else if (S.running && !st.running) { S.running = false; $('btnRun').textContent = '▶ 実行'; $('runChip').textContent = '停止'; $('runChip').className = 'chip'; }
    if (S.running && S.step < RAMP + 50) await sendParams();
    if (st.hist.length) updateReadouts();
    const now = performance.now();
    if ((S.running || S.visDirty) && now - (S.lastField || 0) > FIELD_MS) { S.lastField = now; S.visDirty = false; await refreshVisuals(); }
  } catch (e) {
    $('gpuChip').textContent = 'サーバ応答なし'; $('gpuChip').className = 'chip bad';
  } finally { S.polling = false; }
}
async function refreshVisuals() {
  if (!S.prepared) return;
  const axis = $('sliceAxis').value, field = $('field').value, pos = +$('slicePos').value;
  const jobs = [
    axis === 'none' ? null : apiBin(`/api/slice?axis=${axis}&pos=${pos}&field=${field}&uin=${S.uin}`).then(r => ({ ...r, axis, field, pos })),
    $('showStream').checked ? apiBin('/api/coarse?maxdim=96') : null,
    $('showCp').checked ? apiBin(`/api/cp?uin=${S.uin}`).then(r => r.buf) : null,
  ];
  const [sl, co, cp] = await Promise.all(jobs);
  S.vis = { sl, co, cp };
  buildSlice(sl); buildStreamlines(co); colorSurfaceCp(cp);
  $('legMin').textContent = FIELD_RANGE[field][0]; $('legMax').textContent = FIELD_RANGE[field][1]; $('legName').textContent = $('field').selectedOptions[0].text;
}
function requestVisuals() { S.visDirty = true; S.lastField = 0; }
""")

# 可視化コントロールは再取得をリクエスト
sub("for (const id of ['sliceAxis', 'slicePos', 'field']) $(id).addEventListener('input', refreshVisuals);\n$('showStream').addEventListener('change', refreshVisuals);\n$('showCp').addEventListener('change', refreshVisuals);",
    "for (const id of ['sliceAxis', 'slicePos', 'field']) $(id).addEventListener('input', requestVisuals);\n$('showStream').addEventListener('change', requestVisuals);\n$('showCp').addEventListener('change', requestVisuals);")
# 格子ヒント: プリセットのメモリ見積り
sub(re.search(r"function updateGridHint\(\) \{.*?\n", s).group(0), """function updateGridHint() {
  const o = $('grid').selectedOptions[0]; if (!o) return;
  setHint('gridHint', `${(+o.dataset.cells).toLocaleString()} cells / 約 ${o.dataset.mem} MB (${S.hw ? S.hw.mem_kind.toUpperCase() : ''})`);
}
""")

# ---------------------------------------------------------------- boot
replace_section("boot", """
function populateGrid(hw) {
  const sel = $('grid'); sel.innerHTML = '';
  // 既定: GPU なら 8M cells 以下の最大、CPU なら 2M、NumPy なら 0.5M
  const target = hw.backend === 'numpy' ? 600_000 : hw.backend === 'cpu' ? 2_500_000 : 9_000_000;
  let pick = 0;
  hw.presets.forEach((p, i) => {
    const o = document.createElement('option');
    o.value = `${p.nx},${p.ny},${p.nz}`; o.textContent = `${p.nx}×${p.ny}×${p.nz} (${(p.cells / 1e6).toFixed(1)}M, ${p.mem_mb} MB)`;
    o.dataset.cells = p.cells; o.dataset.mem = p.mem_mb; sel.appendChild(o);
    if (p.cells <= target) pick = i;
  });
  sel.selectedIndex = pick; updateGridHint();
}
(async () => {
  updateCamera(); frame();
  try {
    const hw = await apiJSON('/api/hardware'); S.hw = hw;
    $('gpuChip').textContent = `${hw.backend.toUpperCase()} / ${hw.device}`; $('gpuChip').className = 'chip ok';
    $('memChip').textContent = `${(hw.mem_bytes / 1073741824).toFixed(1)} GB ${hw.mem_kind.toUpperCase()} → 最大 ${(hw.max_cells / 1e6).toFixed(0)}M cells`;
    populateGrid(hw);
    $('msg').hidden = true;
    if (hw.notes.length) setHint('prepHint', hw.notes.join(' / '), 'warn');
    setInterval(poll, POLL_MS);
  } catch (e) {
    $('gpuChip').textContent = 'サーバなし'; $('gpuChip').className = 'chip bad';
    $('msg').textContent = 'ローカルサーバに接続できません: ' + e.message + '  起動スクリプトのウィンドウを確認してください。';
    return;
  }
  try { $('pAhmed').click(); await prep(); await start(); }
  catch (e) { setHint('prepHint', '初期化に失敗: ' + e.message, 'bad'); }
})();
""")

# ---------------------------------------------------------------- 残りの WebGPU 残骸チェック
for bad in ["S.solver", "GPUSolver", "navigator.gpu", "sampleForce", "sampleField", "S.mac", "voxelize()"]:
    assert bad not in s, f"残骸: {bad}"
DST.write_text(s, encoding="utf-8")
print("wrote", DST, len(s))
